﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using FoodOrder.API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using IOrderService.Services;
using Repository.Models;

namespace FoodOrder.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService.Services.OrderService _foodorder;
        private readonly ILogger<OrderController> _logger;
        public OrderController(
          IOrderService.Services.OrderService foodorder,
          ILogger<OrderController> logger
      )
        {
            _foodorder = foodorder;
            _logger = logger;
        }
        //This API will create a new Order.
        //Pushing into the Queue based on POS,In this API I am taking normal Queue 
        //Some Other thoughts are to push the orders to Azure Queues when the order has been raised for diffrent POS and we can write a Azure 
        //Function trigger which picks up the order to process against the POS.

        [HttpPost("PushOrder")]
        public async Task<IActionResult> PushOrders(Orders itemorder)
        {
            if (itemorder.ItemName == string.Empty) {
                return BadRequest("Required data missing");
            }
            var orders = await _foodorder.AddProductAsync(itemorder);

            return Ok(orders);
        }
        [HttpGet("GetOrder")]
        public async Task<IActionResult> GetOrders()
        {
          
            var orders = await _foodorder.GetProducts();

            return Ok(orders);
        }
    }
}