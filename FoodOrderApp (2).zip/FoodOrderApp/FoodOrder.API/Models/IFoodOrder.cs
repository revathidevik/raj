﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodOrder.API.Models
{
    public interface IFoodOrder
    {
        Task<IList<Order>> Orders(long foodTypeId);
    }
}
