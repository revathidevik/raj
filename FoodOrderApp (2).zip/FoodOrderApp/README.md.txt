# Food Order Web App
A sample food order web app is developed using ASP.NET Core, bootstrap, jQuery, HTML localStorage. This project demo how to structure the solutions into different projects also.

## Getting Started
The homepage demo loading the foods listing by calling Web API through the C# backend code. The data is stored in SQL Server and access using Entity Framework with LINQ. 

The frontend UI uses bootstrap3 CSS and jQuery. 

When the button "Create Order" is clicked, the ordered food will be added to the POS queue. 


## Architecture
**FoodOrderAPP** - The ASP.NET Core MVC project 

**Repository** - For the generic IRepository class and DBContext,For all the entities and view models

**OrderService** - For all the business logic, interfaces and data access operations

**FoodOrder.API** - For all the web API methods
**FoodAPPUnitTest**-For Unit Tests

## Prerequisites
.NET Core 3.1, Visual Studio 2019 SQL Server, Entity framework 6.0

## Installing
Change the database connection string in appsettings.Development.json to your local database connection.





