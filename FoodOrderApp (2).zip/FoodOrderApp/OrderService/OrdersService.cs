﻿using System.Threading.Tasks;
using Repository.Models;
using Repository;
using System.Collections.Generic;

namespace IOrderService.Services
{
    public class OrdersService : OrderService
    {
        private readonly IOrdersRepository _productRepository;

        public OrdersService(IOrdersRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public async Task<Orders> GetProductByIdAsync(int id)
        {
            return await _productRepository.GetOrdersByIdAsync(id);
        }

        public async Task<Orders> AddProductAsync(Orders itemOrder)
        {
            return await _productRepository.AddAsync(itemOrder);
        }

        public async Task<List<Orders>> GetProducts()
        {
            return await _productRepository.GetAllOrdersAsync();
        }
    }
}