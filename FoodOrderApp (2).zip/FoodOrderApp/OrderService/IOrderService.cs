﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Repository.Models;

namespace IOrderService.Services
{
    public interface OrderService
    {
        Task<Orders> AddProductAsync(Orders product);

        Task<Orders> GetProductByIdAsync(int id);

        Task<List<Orders>> GetProducts();
    }
}