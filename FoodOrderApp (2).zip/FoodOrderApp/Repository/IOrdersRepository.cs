﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Repository.Models;

namespace Repository
{
    public interface IOrdersRepository : IRepository<Orders>
    {
        Task<Orders> GetOrdersByIdAsync(int id);
        Task<Orders> PostOrdersAsync(Orders ord);
        Task<List<Orders>> GetAllOrdersAsync();
    }
}