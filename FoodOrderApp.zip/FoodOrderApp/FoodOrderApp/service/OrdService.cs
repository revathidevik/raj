﻿using FoodOrderApp.Helper;
using Newtonsoft.Json;
using Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace FoodOrderApp.service
{
    public class OrdService
    {
        public async Task<int> PostOrderAsync(Orders _product)
        {
            //Call an Web API
            OrderHttpClient _ClientInstance = new OrderHttpClient();
            HttpClient clientReq = _ClientInstance.Instance();
            var apiUrl = "api/Order/PushOrder";
            HttpContent content = new StringContent(_product.ToJSON(), Encoding.UTF8, "application/json");
            var result = await clientReq.PostAsync(apiUrl, content);
            if (result.IsSuccessStatusCode)
            {
                return 1;
            }
            return 0;
        }
        public async Task<IEnumerable<Orders>> GetordersAsync()
        {
            List<Orders> products = new List<Orders>();
            //Call an Web API
            OrderHttpClient _ClientInstance = new OrderHttpClient();
            HttpClient clientReq = _ClientInstance.Instance();
            HttpResponseMessage result = await clientReq.GetAsync("api/Values");
            if (result.IsSuccessStatusCode)
            {

                var response = result.Content.ReadAsStringAsync().Result;
                products = JsonConvert.DeserializeObject<List<Orders>>(response);
            }
            return products;
        }
    }
}
