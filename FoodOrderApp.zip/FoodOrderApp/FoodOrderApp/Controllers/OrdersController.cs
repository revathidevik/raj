﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FoodOrderApp.Models;
using FoodOrderApp.service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Repository.Models;

namespace FoodOrderApp.Controllers
{
    public class OrdersController : Controller
    {
        // GET: Orders
        public ActionResult Index()
        {
            var v=new Orders() {Id=1, ItemName = "Pizza", Cost = 200, Quantity = "1", POS = "Grill" };
          //  OrderView ordview = (OrderView)v;
            OrderView ordview = JsonConvert.DeserializeObject<OrderView>(JsonConvert.SerializeObject(v));
            IList<OrderView> lstView = new List<OrderView>();
            lstView.Add(ordview);
            return View(lstView);
        }

        // GET: Orders/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Orders/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Orders/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([FromForm]Orders p)
        {
            try
            {
                p.Id = null;
               // Orders order = new Orders() {Cost=Convert.ToDecimal(collection.Keys["Cost"]),};
                OrdService _ord = new OrdService();
                // TODO: Add insert logic here
                var response = _ord.PostOrderAsync(p);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Orders/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Orders/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Orders/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Orders/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}