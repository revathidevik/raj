﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace FoodOrderApp.Helper
{
    public class OrderHttpClient
    {
        public HttpClient Instance()
        {
            var _client = new HttpClient();
            _client.BaseAddress = new Uri("http://localhost:50964");
            return _client;
        }
    }
}
