﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodOrder.API.Models
{
    enum KitchenPOS
    {
        fries,
        grill,
        salad,
        drink,
        desert
    }
    public class Order
    {
        public int OrderID { get; set; }
        public string OrderBy { get; set; }
        public Enum OrderPOS { get; set; }
        public string Qualtity { get; set; }

        public string Item { get; set; }
       // public string MyProperty { get; set; }
    }
}
