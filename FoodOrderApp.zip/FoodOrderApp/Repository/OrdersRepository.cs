﻿using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Repository;
using Repository.Models;

namespace Repository
{
    public class OrdersRepository : Repository<Orders>, IOrdersRepository
    {
        public OrdersRepository(RepositoryPatternDemoContext repositoryPatternDemoContext) : base(repositoryPatternDemoContext)
        {
        }

        public async Task<Orders> GetOrdersByIdAsync(int id)
        {
            return await GetAll().FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<Orders> PostOrdersAsync(Orders ord)
        {
            return await AddAsync(ord);
        }
    }
}