﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Repository.Models
{
    public partial class Orders
    {
        public int? Id { get; set; }
        public string ItemName { get; set; }
        public string Quantity { get; set; }
        public decimal Cost { get; set; }
        public string POS { get; set; }
        public string ToJSON() => JsonConvert.SerializeObject(this, Newtonsoft.Json.Formatting.None,
                           new JsonSerializerSettings
                           {
                               NullValueHandling = NullValueHandling.Ignore
                           });
    }
    enum KitchenPOS
    {
        fries,
        grill,
        salad,
        drink,
        desert
    }
}
