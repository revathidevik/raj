using NUnit.Framework;
using FoodOrder.API.Controllers;
using IOrderService.Services;
using Microsoft.Extensions.Logging;
using Repository;
using Moq;
using Repository.Models;
using System.Threading.Tasks;
using System.Collections.Generic;
using FoodOrder.API.Models;

namespace FoodAPPUnitTest
{
    public class Tests
    {
        private readonly IOrderService.Services.OrderService _foodorder;
        private readonly ILogger<OrderController> _logger;
        [SetUp]
        public void Setup()
        {
            //_foodorder = OrderService.Services.OrderService
        }

        [Test]
        public void PushOrderUnitTestSuccess()
        {

            Orders ord = new Orders() { ItemName = "Pizza", Cost = 200, Quantity = "1", POS = "Grill" };
            var mock = new Mock<IOrderService.Services.OrderService>();
            mock.Setup(p => p.AddProductAsync(ord)).Returns(Task<Orders>.FromResult<Orders>(ord)).Verifiable(); 
            OrderController _order = new OrderController(_foodorder, _logger);
           var obj= _order.PushOrders(ord);
            Assert.IsNotNull(obj);
        }
        private IEnumerable<Orders> OrderList()
        {
            IList<Orders> order = new List<Orders>()
            {
                new Orders() {ItemName="Pizza",Cost=200,Quantity="1",POS="Grill" }
             };
            return order;
        }
    }
}